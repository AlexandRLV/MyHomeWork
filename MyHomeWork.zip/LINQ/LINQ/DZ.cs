﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ
{
    class DZ
    {
        class Client
        {
            public int Month;
            public int Year;
            public int ID;
            public int Count;

            public Client(int m, int y, int i, int c)
            {
                Month = m;
                Year = y;
                ID = i;
                Count = c;
            }
        }

        public class Abituriend
        {
            public string Name;
            public int SchoolId;
            public int Year;

            public Abituriend(string s, int s1, int y)
            {
                Name = s;
                SchoolId = s1;
                Year = y;
            }
        }

        class Debtor
        {
            public string Name;
            public int Flat;
            public int Debt;

            public Debtor(string n, int f, int d)
            {
                Name = n;
                Flat = f;
                Debt = d;
            }
        }

        class AZS
        {
            public int Mark;
            public string Company;
            public string Street;
            public int Price;

            public AZS(int m, string c, string s, int p)
            {
                Mark = m;
                Company = c;
                Street = s;
                Price = p;
            }
        }

        class Studs
        {
            public int School;
            public string Surname;
            public string Name;
            public string Scores;

            public Studs (int s, string n1, string n2, string c)
            {
                School = s;
                Surname = n1;
                Name = n2;
                Scores = c;
            }
        }

        class Mark
        {
            public int Class;
            public string Name;
            public int Score;
            public string Lesson;

            public Mark(int c, string n, int s, string l)
            {
                Class = c;
                Name = n;
                Score = s;
                Lesson = l;
            }
        }

        class Potreb
        {
            public int Code;
            public string Street;
            public int Year;

            public Potreb(int c, string s, int y)
            {
                Code = c;
                Street = s;
                Year = y;
            }
        }

        class Discount
        {
            public int Value;
            public int Code;
            public string Name;

            public Discount(int v, int c, string n)
            {
                Value = v;
                Code = c;
                Name = n;
            }
        }

        class Tovar
        {
            public string Category;
            public string Country;
            public int Article;

            public Tovar(string c1,string c2,int a)
            {
                Category = c1;
                Country = c2;
                Article = a;
            }
        }

        class Prices
        {
            public int Article;
            public string Name;
            public int Price;

            public Prices(int a, string n, int p)
            {
                Article = a;
                Name = n;
                Price = p;
            }
        }

        class Buys
        {
            public int Code;
            public int Article;
            public string Name;

            public Buys(int c, int a, string n)
            {
                Code = c;
                Article = a;
                Name = n;
            }
        }

        public static void Start()
        {
            //Task 2.
            Console.WriteLine("Task 2");
            List<Client> s1 = new List<Client>() { new Client(1, 1, 3, 4), new Client(2, 2, 3, 5), new Client(2, 1, 3, 6), new Client(2, 2, 3, 7) };
            Client c = s1.OrderBy(a => a.Count).ThenBy(a=>a.Year).ThenBy(a=>a.Month).Last();
            Console.WriteLine($"Count:{c.Count} - Year:{c.Year} - Month:{c.Month}");

            //Task 12
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Task 12");
            int l = 30;
            var s2 = s1.GroupBy(a => a.Year).Select(a => new { Sum = a.Sum(b => b.Count), Months = a.GroupBy(b => b.Month), Year = a.Key }).Select(a => new { Year = a.Year, Counts = a.Months.Select(b => new { Month = b.Key, Count = b.Sum(n => n.Count) }), Sum = a.Sum }).Select(a => new { Year = a.Year, Count = a.Counts.Where(b => a.Sum * (l / 100) < b.Count).Count() });
            foreach (var a in s2)
            {
                Console.WriteLine($"MonthCount:{a.Count} - Year:{a.Year}");
            }

            //Task 22.
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Task 22");
            List<Abituriend> s4 = new List<Abituriend>() { new Abituriend("a", 10, 12), new Abituriend("a", 113, 12), new Abituriend("a", 10, 11) };
            var s5 = s4.GroupBy(a => a.SchoolId).Select(a => new { Years = a.Select(b => new { b.Year }).OrderBy(x => x.Year).ToArray(), Id = a.Key }).OrderBy(a => a.Id);
            foreach (var a in s5)
            {
                Console.Write($"School - {a.Id}");
                foreach (var b in a.Years)
                {
                    Console.Write($" {b}");
                }
                Console.WriteLine();
            }

            //Task 32.
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Task 32");
            List<Debtor> s6 = new List<Debtor>() { new Debtor("1", 12, 15), new Debtor("1", 20, 25), new Debtor("1", 6, 19), new Debtor("1", 30, 10) };
            var q = s6.ConvertAll(a => new { a.Name, a.Debt, a.Flat, Floor = a.Flat / 4 % 9 }).GroupBy(a => a.Floor).Select(a => new { Floor = a.Key, Mindebt = a.Min(b => b.Debt) });
            for (int i = 1; i < 10; i++)
            {
                Console.Write($"{i}-й этаж: ");
                var a = q.ToList().Find(b => b.Floor == i);
                if (a != null)
                {
                    Console.Write($"{a.Mindebt}  ");
                }
                else
                {
                    Console.Write("0  ");
                }
            }

            //Task 42.
            Console.WriteLine();            
            Console.WriteLine();
            Console.WriteLine("Task 42");
            List<AZS> s8 = new List<AZS>() { new AZS(92, "w1", "e1", 10), new AZS(95, "w2", "e1", 10), new AZS(95, "w2", "e2", 15), new AZS(98, "w2", "e1", 20), new AZS(92, "w1", "e2", 25), new AZS(98, "w3", "e2", 10) };
            var s9 = s8.GroupBy(a => a.Street).Select(a => new { Street = a.Key, Price92 = a.Select(b => new { mark = b.Mark, price = b.Price }).Where(b => b.mark == 92).Min(b => b.price), Price95 = a.Select(b => new { mark = b.Mark, price = b.Price }).Where(b => b.mark == 95).Min(b => b.price), Price98 = a.Select(b => new { mark = b.Mark, price = b.Price }).Where(b => b.mark == 98).Min(b => b.price) });
            foreach (var b in s9)
            {
                Console.WriteLine($"Street:{b.Street} - 92:{b.Price92} - 95:{b.Price95} - 98:{b.Price98}");
            }

            //Task 52.
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Task 52");
            List<Studs> z1 = new List<Studs>() { new Studs(10, "q", "q.w.", "50 60 70"), new Studs(11, "a", "a.s.", "60 65 70"), new Studs(10, "b", "h.g.", "50 60 50") };
            var z2 = z1.ConvertAll(a => new { a.Name, a.School, a.Surname, a.Scores, AvScore = a.Scores.Split(' ').Select(b => int.Parse(b)).Average() }).GroupBy(a => a.School).Select(a => new { a.Key, Stud = a.OrderBy(b=>b.AvScore).First() });
            foreach (var a in z2)
            {
                Console.WriteLine($"School: {a.Key} - Name: {a.Stud.Name} - Surname: {a.Stud.Surname} - Score: {a.Stud.AvScore}");
            }


            //Task 62.
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Task 62");
            List<Mark> z4 = new List<Mark>() { new Mark(5, "q", 5, "g"), new Mark(4, "w", 4, "i"), new Mark(5, "q", 3, "a") };
            var z5 = z4.GroupBy(a => a.Name).Select(a => new { Name = a.Key, Class = a.ElementAt(0).Class, Gcount = a.Where(b => b.Lesson == "g").Count(), Icount = a.Where(b => b.Lesson == "i").Count(), Acount = a.Where(b => b.Lesson == "a").Count() }).OrderBy(a => a.Class).ThenBy(a=>a.Name);
            foreach (var a in z5)
            {
                Console.WriteLine($"Class: {a.Class}, Name: {a.Name} - Alg:{a.Acount}, Geom:{a.Gcount}, Inf:{a.Icount}");
            }


            //Task 72.
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Task 72");
            List<Potreb> z7 = new List<Potreb>() { new Potreb(1, "q", 1), new Potreb(2, "w", 1), new Potreb(3, "w", 3), new Potreb(4, "q", 2) };
            List<Discount> z8 = new List<Discount>() { new Discount(10, 1, "a"), new Discount(15, 2, "s"), new Discount(10, 3, "a"), new Discount(20, 4, "s") };
            var z9 = z8.GroupBy(a => a.Code);
            foreach (var b in z9)
            {
                Console.WriteLine($"ShopsCount: {b.Count()} - PotrebCode: {b.First().Code} - Street: {z7.Find(a=>a.Code==b.Key).Street}");
            }
        }
    }
}
