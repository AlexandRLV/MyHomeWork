﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ
{
    public class Letter
    {
        public char c = 'a';
        int end;

        public Letter(int end)
        {
            this.end = end;
        }
    }

    public class Student
    {
        public int Num { get; set; }
        public string Group { get; set; }
        public string Name { get; set; }
        public int AvMark { get; set; }

        public Student(int n, string a, string g, int m)
        {
            Num = n;
            Group = g;
            Name = a;
            AvMark = m;
        }

        
        public override string ToString()
        {
            return $"{Num}: {Group}, {Name} - {AvMark}";
        }
        
    }

    class Program
    {
        public static void Start()
        {
            //List<Student> s = new List<Student>();
            //s.Add(new Student(1, "IGOR", "LOLOTeam", 60));
            //s.Add(new Student(2, "Petr", "KoPM2Clan", 80));
            //s.Add(new Student(3, "Vasya", "NoMercyForExams", 90));
            //s.Add(new Student(4, "KTULHU", "KuKlusClan", 50));


            //foreach(Student a in s)
            //{
            //    Console.WriteLine(a);
            //}
            //Console.WriteLine();
            //var st = s.Where(b => b.AvMark > 95);

            //if (st.Count() <= 0)
            //{
            //    Console.WriteLine("Empty");
            //}
            //foreach (Student a in st)
            //{
            //    Console.WriteLine(a);
            //}
            //Console.WriteLine();
            //Console.WriteLine($"Maximal mark: {s.Max(a=>a.AvMark)}");
            //s.Sort((a, b) => a.AvMark > b.AvMark ? 1 : (a.AvMark < b.AvMark ? -1 : 0));
            //foreach (Student a in s)
            //{
            //    Console.WriteLine(a);
            //}
            //Console.WriteLine();
            //var s1 = s.OrderBy(a => a.Name);
            //foreach (Student a in s1)
            //{
            //    Console.WriteLine(a);
            //}

            //var s2 = s.Take(2);
            //Console.WriteLine();
            //foreach (Student a in s2)
            //{
            //    Console.WriteLine(a);
            //}

            //Console.WriteLine();
            //var s3 = s.Skip(2);
            //foreach (Student a in s3)
            //{
            //    Console.WriteLine(a);
            //}
            //Console.WriteLine(s.Take(3).All(a => a.AvMark > 10));
            //Console.WriteLine();
            //var s4 = s.Select(a => a.Name);
            //foreach(string a in s4)
            //{
            //    Console.WriteLine(a);
            //}
            //Console.WriteLine();
            //var s5 = s.Select(a => new { a.Name, a.AvMark });
            //foreach (var a in s5)
            //{
            //    Console.WriteLine($"{a.Name} - {a.AvMark}");
            //}

            //int x = int.Parse(Console.ReadLine());
            //List<int> nums = new List<int>() { 11, 12, 13, 2134, 63, 231, 567, 132, 11, 13, 113 };
            //Console.WriteLine($"{nums.First(a => a % 10 == x)}");
            //Console.WriteLine();
            //var num = nums.Where(a => a % 2 != 0).Distinct();
            //foreach (int a in num)
            //{
            //    Console.Write($"{a} ");
            //}
            //Console.WriteLine();
            //x = int.Parse(Console.ReadLine());
            //var num1 = nums.Skip(x - 1).Where(a => a / 100 == 0 && a % 2 != 0).OrderByDescending(a => a);
            //Console.WriteLine();
            //foreach (int a in num1)
            //{
            //    Console.Write($"{a} ");
            //}
            //List<string> words = new List<string>() { "as", "qwe", "asdqw", "wqwe", "dgrhtr", "irndi", "ikdofv" };
            //var str = words.Select(s => s.Length % 2 != 0 ? s[0] : s[s.Length - 1]).OrderByDescending(c => c);
            //Console.WriteLine();
            //foreach (char a in str)
            //{
            //    Console.Write(a+" ");
            //}
        }

        static void Main(string[] args)
        {
            DZ.Start();
        }
    }
}
